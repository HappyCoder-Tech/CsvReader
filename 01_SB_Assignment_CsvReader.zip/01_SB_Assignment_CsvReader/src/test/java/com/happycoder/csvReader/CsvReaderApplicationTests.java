package com.happycoder.csvReader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
