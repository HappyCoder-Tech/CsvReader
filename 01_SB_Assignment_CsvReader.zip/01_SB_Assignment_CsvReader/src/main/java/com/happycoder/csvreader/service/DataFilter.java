package com.happycoder.csvreader.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.happycoder.csvreader.model.Product;

@Service
public class DataFilter {

	public List<Product> filterData(List<Product> productList) {
		
		return productList.stream().filter(e -> e.getPrize()>5000).collect(Collectors.toList());
	}

}
