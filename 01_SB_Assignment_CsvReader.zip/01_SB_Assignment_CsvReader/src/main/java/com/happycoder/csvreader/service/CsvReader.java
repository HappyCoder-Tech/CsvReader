package com.happycoder.csvreader.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.happycoder.csvreader.model.Product;

@Service
public class CsvReader {
	
	@Autowired
	private DataFilter dataFilter;
	
	public List<Product> readAndFilterCsv() throws NumberFormatException, IOException{

		String line = "";
		List<Product> productList = new ArrayList<Product>();
		String inputFile = "products.csv";
		Path path = Paths.get(inputFile);
		
		BufferedReader csvReader = new BufferedReader(new FileReader("Product.txt"));
		while((line = csvReader.readLine())!= null) {
			String[] prd = line.split(",");
			Product product = new Product(Integer.parseInt(prd[0]), prd[1], Double.parseDouble(prd[2]));	
			productList.add(product);
		}
		
		return dataFilter.filterData(productList);
	}
	

}
