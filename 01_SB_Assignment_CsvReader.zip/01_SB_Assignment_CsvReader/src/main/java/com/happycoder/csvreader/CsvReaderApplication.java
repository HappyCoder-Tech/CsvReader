package com.happycoder.csvreader;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.happycoder.csvreader.model.Product;
import com.happycoder.csvreader.service.CsvReader;

@SpringBootApplication
public class CsvReaderApplication {

	public static void main(String[] args) throws NumberFormatException, IOException {
		ConfigurableApplicationContext ctxt = SpringApplication.run(CsvReaderApplication.class, args);
		CsvReader bean = ctxt.getBean(CsvReader.class);
		List<Product> productList = bean.readAndFilterCsv();
		System.out.println(productList.toString());
	}
	
	

}
